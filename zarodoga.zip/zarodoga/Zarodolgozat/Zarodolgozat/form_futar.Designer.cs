﻿namespace Zarodolgozat
{
    partial class form_futar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.numericUpDown_fazon = new System.Windows.Forms.NumericUpDown();
            this.button_vevo_torles = new System.Windows.Forms.Button();
            this.button_vevo_rogzites = new System.Windows.Forms.Button();
            this.button_vevo_modosit = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.textbox_fnev = new System.Windows.Forms.TextBox();
            this.listBox_futar = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_fazon)).BeginInit();
            this.SuspendLayout();
            // 
            // numericUpDown_fazon
            // 
            this.numericUpDown_fazon.Location = new System.Drawing.Point(522, 33);
            this.numericUpDown_fazon.Name = "numericUpDown_fazon";
            this.numericUpDown_fazon.Size = new System.Drawing.Size(100, 20);
            this.numericUpDown_fazon.TabIndex = 20;
            // 
            // button_vevo_torles
            // 
            this.button_vevo_torles.Location = new System.Drawing.Point(478, 247);
            this.button_vevo_torles.Name = "button_vevo_torles";
            this.button_vevo_torles.Size = new System.Drawing.Size(110, 40);
            this.button_vevo_torles.TabIndex = 19;
            this.button_vevo_torles.Text = "Törlés";
            this.button_vevo_torles.UseVisualStyleBackColor = true;
            this.button_vevo_torles.Click += new System.EventHandler(this.button_vevo_torles_Click);
            // 
            // button_vevo_rogzites
            // 
            this.button_vevo_rogzites.Location = new System.Drawing.Point(538, 187);
            this.button_vevo_rogzites.Name = "button_vevo_rogzites";
            this.button_vevo_rogzites.Size = new System.Drawing.Size(110, 36);
            this.button_vevo_rogzites.TabIndex = 18;
            this.button_vevo_rogzites.Text = "Rögzítés";
            this.button_vevo_rogzites.UseVisualStyleBackColor = true;
            this.button_vevo_rogzites.Click += new System.EventHandler(this.button_vevo_rogzites_Click);
            // 
            // button_vevo_modosit
            // 
            this.button_vevo_modosit.Location = new System.Drawing.Point(407, 187);
            this.button_vevo_modosit.Name = "button_vevo_modosit";
            this.button_vevo_modosit.Size = new System.Drawing.Size(110, 35);
            this.button_vevo_modosit.TabIndex = 17;
            this.button_vevo_modosit.Text = "Módosít";
            this.button_vevo_modosit.UseVisualStyleBackColor = true;
            this.button_vevo_modosit.Click += new System.EventHandler(this.button_vevo_modosit_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(436, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 18);
            this.label2.TabIndex = 15;
            this.label2.Text = "Futár neve:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(456, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 18);
            this.label1.TabIndex = 14;
            this.label1.Text = "Futár id:";
            // 
            // textbox_fnev
            // 
            this.textbox_fnev.Location = new System.Drawing.Point(521, 96);
            this.textbox_fnev.Name = "textbox_fnev";
            this.textbox_fnev.Size = new System.Drawing.Size(101, 20);
            this.textbox_fnev.TabIndex = 13;
            // 
            // listBox_futar
            // 
            this.listBox_futar.FormattingEnabled = true;
            this.listBox_futar.Location = new System.Drawing.Point(-1, 5);
            this.listBox_futar.Name = "listBox_futar";
            this.listBox_futar.Size = new System.Drawing.Size(306, 290);
            this.listBox_futar.TabIndex = 11;
            this.listBox_futar.SelectedIndexChanged += new System.EventHandler(this.listBox_futar_SelectedIndexChanged);
            // 
            // form_futar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(911, 538);
            this.Controls.Add(this.numericUpDown_fazon);
            this.Controls.Add(this.button_vevo_torles);
            this.Controls.Add(this.button_vevo_rogzites);
            this.Controls.Add(this.button_vevo_modosit);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textbox_fnev);
            this.Controls.Add(this.listBox_futar);
            this.Name = "form_futar";
            this.Text = "form_futar";
            this.Load += new System.EventHandler(this.form_futar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_fazon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown numericUpDown_fazon;
        private System.Windows.Forms.Button button_vevo_torles;
        private System.Windows.Forms.Button button_vevo_rogzites;
        private System.Windows.Forms.Button button_vevo_modosit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textbox_fnev;
        private System.Windows.Forms.ListBox listBox_futar;
    }
}