﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zarodolgozat
{
    internal class Users
    {
        int user_id;
        string bejelentkezes_felhasz;
        string bejelentkezes_jelszo;

        public int User_id { get => user_id; set => user_id = value; }

        public string Bejelentkezes_felhasz { get => bejelentkezes_felhasz; set => bejelentkezes_felhasz = value; }

        public string Bejelentkezes_jelszo { get => bejelentkezes_jelszo; set => bejelentkezes_jelszo = value; }



        public Users(int user_id, string bejelentkezes_felhasz, string bejelentkezes_jelszo)
        {
            User_id = user_id;
            Bejelentkezes_felhasz = bejelentkezes_felhasz;
            Bejelentkezes_jelszo = bejelentkezes_jelszo;
        }
    }
}
