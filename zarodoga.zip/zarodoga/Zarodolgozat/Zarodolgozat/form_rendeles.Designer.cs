﻿namespace Zarodolgozat
{
    partial class form_rendeles
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_exit = new System.Windows.Forms.Button();
            this.numericUpDown_razon = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.listBox_rendeles = new System.Windows.Forms.ListBox();
            this.numericUpDown_vazon = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.numericUpDown_fazon = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.dateTimePicker_rendeles = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_razon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_vazon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_fazon)).BeginInit();
            this.SuspendLayout();
            // 
            // button_exit
            // 
            this.button_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_exit.ForeColor = System.Drawing.Color.Black;
            this.button_exit.Location = new System.Drawing.Point(773, 488);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(126, 38);
            this.button_exit.TabIndex = 106;
            this.button_exit.Text = "Vissza";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // numericUpDown_razon
            // 
            this.numericUpDown_razon.Location = new System.Drawing.Point(489, 181);
            this.numericUpDown_razon.Name = "numericUpDown_razon";
            this.numericUpDown_razon.ReadOnly = true;
            this.numericUpDown_razon.Size = new System.Drawing.Size(99, 20);
            this.numericUpDown_razon.TabIndex = 105;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(394, 181);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(89, 18);
            this.label1.TabIndex = 99;
            this.label1.Text = "Rendelés id:";
            // 
            // listBox_rendeles
            // 
            this.listBox_rendeles.Dock = System.Windows.Forms.DockStyle.Left;
            this.listBox_rendeles.FormattingEnabled = true;
            this.listBox_rendeles.Location = new System.Drawing.Point(0, 0);
            this.listBox_rendeles.Name = "listBox_rendeles";
            this.listBox_rendeles.Size = new System.Drawing.Size(239, 538);
            this.listBox_rendeles.TabIndex = 96;
            this.listBox_rendeles.SelectedIndexChanged += new System.EventHandler(this.listBox_rendeles_SelectedIndexChanged);
            // 
            // numericUpDown_vazon
            // 
            this.numericUpDown_vazon.Location = new System.Drawing.Point(489, 222);
            this.numericUpDown_vazon.Name = "numericUpDown_vazon";
            this.numericUpDown_vazon.ReadOnly = true;
            this.numericUpDown_vazon.Size = new System.Drawing.Size(99, 20);
            this.numericUpDown_vazon.TabIndex = 109;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(423, 222);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 18);
            this.label2.TabIndex = 108;
            this.label2.Text = "Vevő id:";
            // 
            // numericUpDown_fazon
            // 
            this.numericUpDown_fazon.Location = new System.Drawing.Point(489, 268);
            this.numericUpDown_fazon.Name = "numericUpDown_fazon";
            this.numericUpDown_fazon.ReadOnly = true;
            this.numericUpDown_fazon.Size = new System.Drawing.Size(99, 20);
            this.numericUpDown_fazon.TabIndex = 111;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(422, 268);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 18);
            this.label3.TabIndex = 110;
            this.label3.Text = "Futár id:";
            // 
            // dateTimePicker_rendeles
            // 
            this.dateTimePicker_rendeles.Location = new System.Drawing.Point(489, 313);
            this.dateTimePicker_rendeles.Name = "dateTimePicker_rendeles";
            this.dateTimePicker_rendeles.Size = new System.Drawing.Size(186, 20);
            this.dateTimePicker_rendeles.TabIndex = 112;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(375, 315);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 18);
            this.label4.TabIndex = 113;
            this.label4.Text = "Rendelés ideje:";
            // 
            // form_rendeles
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(911, 538);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.dateTimePicker_rendeles);
            this.Controls.Add(this.numericUpDown_fazon);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.numericUpDown_vazon);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.numericUpDown_razon);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.listBox_rendeles);
            this.Name = "form_rendeles";
            this.Text = "form_rendeles";
            this.Load += new System.EventHandler(this.form_rendeles_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_razon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_vazon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_fazon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.NumericUpDown numericUpDown_razon;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBox_rendeles;
        private System.Windows.Forms.NumericUpDown numericUpDown_vazon;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown numericUpDown_fazon;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DateTimePicker dateTimePicker_rendeles;
        private System.Windows.Forms.Label label4;
    }
}