﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zarodolgozat
{
    internal class Tetel
    {
        int mazon;
        int razon;
        int db;

        public int Mazon { get => mazon; set => mazon = value; }

        public int Razon { get => razon; set => razon = value; }

        public int Db { get => db; set => db = value; }

        

        public Tetel(int razon, int mazon, int db)
        {
            Razon = razon;
            Mazon = mazon;
            Db = db;
        }
    }
}
