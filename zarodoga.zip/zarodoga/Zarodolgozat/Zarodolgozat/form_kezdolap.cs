﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace Zarodolgozat
{
    public partial class form_kezdolap : Form
    {
        MySqlConnection connect = null;
        MySqlCommand cmd = null;
        public form_kezdolap()
        {
            InitializeComponent();
        }

        private void form_kezdolap_Load(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder builder = new MySqlConnectionStringBuilder();
            builder.Server = "localhost";
            builder.UserID = "root";
            builder.Password = "";
            builder.Database = "zarodolgozat_hadhazi";
            connect = new MySqlConnection(builder.ConnectionString);
            try
            {
                connect.Open();
                cmd = connect.CreateCommand();
            }
            catch (MySqlException ex)
            {

                MessageBox.Show(ex.Message + Environment.NewLine + "A program leált");
                Environment.Exit(0);
            }
            finally
            {
                connect.Close();
            }
        }

        private void button_vevo_form_Click(object sender, EventArgs e)
        {
            Program.Form_Vevo.ShowDialog();
        }

        private void button_futar_form_Click(object sender, EventArgs e)
        {
            Program.Form_Futar.ShowDialog();
        }
    }
}
