﻿namespace Zarodolgozat
{
    partial class form_kezdolap
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_kezdolap));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button_vevo_form = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button_futar_form = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(199, 201);
            this.pictureBox1.TabIndex = 83;
            this.pictureBox1.TabStop = false;
            // 
            // button_vevo_form
            // 
            this.button_vevo_form.Location = new System.Drawing.Point(261, 98);
            this.button_vevo_form.Name = "button_vevo_form";
            this.button_vevo_form.Size = new System.Drawing.Size(121, 40);
            this.button_vevo_form.TabIndex = 85;
            this.button_vevo_form.Text = "Vevő adatok megtekintése";
            this.button_vevo_form.UseVisualStyleBackColor = true;
            this.button_vevo_form.Click += new System.EventHandler(this.button_vevo_form_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(-2, 204);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 18);
            this.label1.TabIndex = 86;
            // 
            // button_futar_form
            // 
            this.button_futar_form.Location = new System.Drawing.Point(388, 98);
            this.button_futar_form.Name = "button_futar_form";
            this.button_futar_form.Size = new System.Drawing.Size(121, 40);
            this.button_futar_form.TabIndex = 87;
            this.button_futar_form.Text = "Futár adatok megtekintése";
            this.button_futar_form.UseVisualStyleBackColor = true;
            this.button_futar_form.Click += new System.EventHandler(this.button_futar_form_Click);
            // 
            // button_exit
            // 
            this.button_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_exit.ForeColor = System.Drawing.Color.Black;
            this.button_exit.Location = new System.Drawing.Point(773, 488);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(126, 38);
            this.button_exit.TabIndex = 88;
            this.button_exit.Text = "Kilépés";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(515, 98);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(121, 40);
            this.button1.TabIndex = 89;
            this.button1.Text = "Menu adatok megtekintése";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(414, 313);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(121, 40);
            this.button2.TabIndex = 90;
            this.button2.Text = "Rendelés adatok megtekintése";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // form_kezdolap
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(911, 538);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.button_futar_form);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_vevo_form);
            this.Controls.Add(this.pictureBox1);
            this.Name = "form_kezdolap";
            this.Text = "form_kezdolap";
            this.Load += new System.EventHandler(this.form_kezdolap_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button_vevo_form;
        private System.Windows.Forms.Button button_futar_form;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.Button button1;
        public System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button2;
    }
}