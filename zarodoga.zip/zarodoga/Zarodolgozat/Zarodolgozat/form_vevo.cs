﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zarodolgozat
{
    public partial class form_vevo : Form
    {
        MySqlConnection connect = null;
        MySqlCommand cmd = null;
        public form_vevo()
        {
            InitializeComponent();
        }

        private void Form_vevo_Load(object sender, EventArgs e)
        {
            
            MySqlConnectionStringBuilder builder = new MySqlConnectionStringBuilder();
            builder.Server = "localhost";
            builder.UserID = "root";
            builder.Password = "";
            builder.Database = "zarodolgozat_hadhazi";
            connect = new MySqlConnection(builder.ConnectionString);
            try
            {
                connect.Open();
                cmd = connect.CreateCommand();
            }
            catch (MySqlException ex)
            {

                MessageBox.Show(ex.Message + Environment.NewLine + "A program leált");
                Environment.Exit(0);
            }
            finally
            {
                connect.Close();
            }
            vevo_list_update();


        }
        private void vevo_list_update()
        {
            listBox_vevo.Items.Clear();
            cmd.CommandText = "SELECT * FROM `vevo`";
            connect.Open();
            using (MySqlDataReader dr = cmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    Vevo uj = new Vevo(dr.GetInt32("vazon"), dr.GetString("vnev"), dr.GetString("vcim"));
                    listBox_vevo.Items.Add(uj);
                }
            }
            connect.Close();
        }

        private void button_vevo_modosit_Click(object sender, EventArgs e)
        {
            if (listBox_vevo.SelectedIndex < 0)
            {
                MessageBox.Show("Nincs kijelölve adat!");
                return;
            }
            Vevo kivalasztott_adat = (Vevo)listBox_vevo.SelectedItem;
            cmd.CommandText = "UPDATE `vevo` SET vnev = @vnev, vcim = @vcim   WHERE vazon = @vazon";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@vazon", numericUpDown_vazon.Value);
            cmd.Parameters.AddWithValue("@vnev", textbox_vnev.Text);
            cmd.Parameters.AddWithValue("@vcim", textBox_vcim.Text);
            connect.Open();
            if (cmd.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Módosítás sikeres");
                connect.Close();
                textbox_vnev.Text = "";
                textBox_vcim.Text = "";
                numericUpDown_vazon.Value = numericUpDown_vazon.Minimum;
                vevo_list_update();
            }
            else
            {
                MessageBox.Show("Az adatok Módosítása sikertelen!");

            }
            if (connect.State == ConnectionState.Open)
            {
                connect.Close();
            
            }
        }

        private void listBox_vevo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox_vevo.SelectedIndex < 0)
            {
                return;
            }
            Vevo kivaasztott_adat = (Vevo)listBox_vevo.SelectedItem;
            textbox_vnev.Text = kivaasztott_adat.Vnev;
            textBox_vcim.Text = kivaasztott_adat.Vcim;
            numericUpDown_vazon.Value = Convert.ToDecimal(kivaasztott_adat.Vazon);
        }

        private void button_vevo_rogzites_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textbox_vnev.Text))
            {
                MessageBox.Show("Adja meg a nevet");
                textbox_vnev.Focus();
                return;
            }
            if (numericUpDown_vazon.Value < 0)
            {
                MessageBox.Show("Érvénytelen egységár!");
                numericUpDown_vazon.Focus();
                return;
            }
            if (string.IsNullOrEmpty(textBox_vcim.Text))
            {
                MessageBox.Show("Adja meg a címet");
                textBox_vcim.Focus();
                return;
            }
            cmd.CommandText = "INSERT INTO `vevo` (`vazon`, `vnev`, `vcim`) VALUES (@vazon, @vnev, @vcim);";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@vazon", numericUpDown_vazon.Value);
            cmd.Parameters.AddWithValue("@vnev", textbox_vnev.Text);
            cmd.Parameters.AddWithValue("@vcim", textBox_vcim.Text);
            connect.Open();
            try
            {
                if (cmd.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Sikeres adat rögzítés");
                    textBox_vcim.Text = "";
                    textbox_vnev.Text = "";
                    numericUpDown_vazon.Value = numericUpDown_vazon.Minimum;

                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);

            }
            connect.Close();
            vevo_list_update();
        }

        private void button_vevo_torles_Click(object sender, EventArgs e)
        {
            if (listBox_vevo.SelectedIndex < 0)
            {
                return;
            }
            cmd.CommandText = "DELETE FROM `vevo` WHERE vazon = @vazon";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@vazon", numericUpDown_vazon.Value);
            connect.Open();

            if (cmd.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("A törlés sikeres!");
                connect.Close();
                textbox_vnev.Text = "";
                textBox_vcim.Text = "";
                numericUpDown_vazon.Value = numericUpDown_vazon.Minimum;
                vevo_list_update();
            }
            else
            {
                MessageBox.Show("A törlés sikertelen!");
            }
            connect.Close();
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            Program.Form_Vevo.Close();
        }

        private void button_clean_Click(object sender, EventArgs e)
        {
            textbox_vnev.Text = "";
            textBox_vcim.Text = "";
            numericUpDown_vazon.Value = numericUpDown_vazon.Minimum;
        }
    }
}
