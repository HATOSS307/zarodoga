﻿using MySql.Data.MySqlClient;
using MySql.Data.Types;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zarodolgozat
{
    public partial class form_rendeles : Form
    {
        MySqlConnection connect = null;
        MySqlCommand cmd = null;
        public form_rendeles()
        {
            InitializeComponent();
        }

        private void form_rendeles_Load(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder builder = new MySqlConnectionStringBuilder();
            builder.Server = "localhost";
            builder.UserID = "root";
            builder.Password = "";
            builder.Database = "zarodolgozat_hadhazi";
            connect = new MySqlConnection(builder.ConnectionString);
            try
            {
                connect.Open();
                cmd = connect.CreateCommand();
            }
            catch (MySqlException ex)
            {

                MessageBox.Show(ex.Message + Environment.NewLine + "A program leált");
                Environment.Exit(0);
            }
            finally
            {
                connect.Close();
            }
            rendeles_list_update();
        }

        private void rendeles_list_update()
        {
            listBox_rendeles.Items.Clear();
            cmd.CommandText = "SELECT * FROM `rendeles`";
            connect.Open();
            using (MySqlDataReader dr = cmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    Rendeles uj = new Rendeles(dr.GetInt32("fazon"), dr.GetInt32("razon"), dr.GetInt32("vazon"),dr.GetDateTime("idopont"));
                    listBox_rendeles.Items.Add(uj);
                }
            }
            connect.Close();
        }

        private void listBox_rendeles_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox_rendeles.SelectedIndex < 0)
            {
                return;
            }
            Rendeles kivaasztott_adat = (Rendeles)listBox_rendeles.SelectedItem;
            numericUpDown_fazon.Value = Convert.ToDecimal(kivaasztott_adat.Fazon);
            numericUpDown_razon.Value = Convert.ToDecimal(kivaasztott_adat.Razon);
            numericUpDown_vazon.Value = Convert.ToDecimal(kivaasztott_adat.Vazon);
            dateTimePicker_rendeles.Value = kivaasztott_adat.Idopont;
        }
        private void button_exit_Click(object sender, EventArgs e)
        {
            Program.Form_Rendeles.Close();
        }
    }
}









