﻿using MySql.Data.MySqlClient;
using MySql.Data.Types;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zarodolgozat
{
    public partial class form_rendeles : Form
    {
        MySqlConnection connect = null;
        MySqlCommand cmd = null;
        public form_rendeles()
        {
            InitializeComponent();
        }

        private void form_rendeles_Load(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder builder = new MySqlConnectionStringBuilder();
            builder.Server = "localhost";
            builder.UserID = "root";
            builder.Password = "";
            builder.Database = "zarodolgozat_hadhazi";
            connect = new MySqlConnection(builder.ConnectionString);
            try
            {
                connect.Open();
                cmd = connect.CreateCommand();
            }
            catch (MySqlException ex)
            {

                MessageBox.Show(ex.Message + Environment.NewLine + "A program leált");
                Environment.Exit(0);
            }
            finally
            {
                connect.Close();
            }
            rendeles_list_update();
        }

        private void rendeles_list_update()
        {
            listBox_rendeles.Items.Clear();
            cmd.CommandText = "SELECT rendeles.idopont as idopont,vevo.vnev as vevőnév, vevo.vcim as vevőcím, futar.fnev as futárnév, tetel.db as darabszám,menu.mnev as menünév, menu.mar*tetel.db as tételár FROM `rendeles` JOIN vevo USING(vazon) JOIN tetel USING(razon) JOIN menu USING(mazon) JOIN futar USING(fazon)";
            connect.Open();
            using (MySqlDataReader dr = cmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    Rendeles uj = new Rendeles(dr.GetDateTime("idopont"), dr.GetString("vevőnév"), dr.GetString("vevőcím") , dr.GetString("futárnév"),dr.GetInt32("darabszám"),dr.GetString("menünév"),dr.GetInt32("tételár"));
                    listBox_rendeles.Items.Add(uj);
                }
            }
            connect.Close();
        }

        private void listBox_rendeles_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox_rendeles.SelectedIndex < 0)
            {
                return;
            }
            Rendeles kivaasztott_adat = (Rendeles)listBox_rendeles.SelectedItem;
            textbox_mnev.Text = kivaasztott_adat.Menunev;
            dateTimePicker_rendeles.Value = kivaasztott_adat.Idopont;
            textbox_vnev.Text = kivaasztott_adat.Vevonev;
            numericUpDown_mar.Value = Convert.ToDecimal(kivaasztott_adat.Menuar);          
            textBox_vcim.Text = kivaasztott_adat.Vevocim;
            textbox_fnev.Text = kivaasztott_adat.Futarnev;
            numericUpDown_darabszam.Value = Convert.ToDecimal(kivaasztott_adat.Tetel_darab);

        }
        private void button_exit_Click(object sender, EventArgs e)
        {
            Program.Form_Rendeles.Close();        
        }
    }
}