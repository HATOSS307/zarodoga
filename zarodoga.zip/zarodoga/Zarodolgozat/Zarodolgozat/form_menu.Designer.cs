﻿namespace Zarodolgozat
{
    partial class form_menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_exit = new System.Windows.Forms.Button();
            this.numericUpDown_mazon = new System.Windows.Forms.NumericUpDown();
            this.button_vevo_torles = new System.Windows.Forms.Button();
            this.button_vevo_rogzites = new System.Windows.Forms.Button();
            this.button_vevo_modosit = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textbox_mnev = new System.Windows.Forms.TextBox();
            this.listBox_menu = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.numericUpDown_mar = new System.Windows.Forms.NumericUpDown();
            this.button_clean = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_mazon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_mar)).BeginInit();
            this.SuspendLayout();
            // 
            // button_exit
            // 
            this.button_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_exit.ForeColor = System.Drawing.Color.Black;
            this.button_exit.Location = new System.Drawing.Point(773, 474);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(131, 39);
            this.button_exit.TabIndex = 91;
            this.button_exit.Text = "Vissza";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // numericUpDown_mazon
            // 
            this.numericUpDown_mazon.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.numericUpDown_mazon.Location = new System.Drawing.Point(487, 151);
            this.numericUpDown_mazon.Name = "numericUpDown_mazon";
            this.numericUpDown_mazon.Size = new System.Drawing.Size(54, 29);
            this.numericUpDown_mazon.TabIndex = 90;
            // 
            // button_vevo_torles
            // 
            this.button_vevo_torles.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_vevo_torles.Location = new System.Drawing.Point(773, 416);
            this.button_vevo_torles.Name = "button_vevo_torles";
            this.button_vevo_torles.Size = new System.Drawing.Size(131, 52);
            this.button_vevo_torles.TabIndex = 89;
            this.button_vevo_torles.Text = "Végleges Törlés";
            this.button_vevo_torles.UseVisualStyleBackColor = true;
            this.button_vevo_torles.Click += new System.EventHandler(this.button_vevo_torles_Click);
            // 
            // button_vevo_rogzites
            // 
            this.button_vevo_rogzites.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_vevo_rogzites.Location = new System.Drawing.Point(685, 295);
            this.button_vevo_rogzites.Name = "button_vevo_rogzites";
            this.button_vevo_rogzites.Size = new System.Drawing.Size(110, 40);
            this.button_vevo_rogzites.TabIndex = 88;
            this.button_vevo_rogzites.Text = "Rögzítés";
            this.button_vevo_rogzites.UseVisualStyleBackColor = true;
            this.button_vevo_rogzites.Click += new System.EventHandler(this.button_vevo_rogzites_Click);
            // 
            // button_vevo_modosit
            // 
            this.button_vevo_modosit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_vevo_modosit.Location = new System.Drawing.Point(551, 295);
            this.button_vevo_modosit.Name = "button_vevo_modosit";
            this.button_vevo_modosit.Size = new System.Drawing.Size(115, 40);
            this.button_vevo_modosit.TabIndex = 87;
            this.button_vevo_modosit.Text = "Módosít";
            this.button_vevo_modosit.UseVisualStyleBackColor = true;
            this.button_vevo_modosit.Click += new System.EventHandler(this.button_vevo_modosit_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(356, 223);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 24);
            this.label3.TabIndex = 86;
            this.label3.Text = "Menü ára(Ft):";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(370, 186);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(111, 24);
            this.label2.TabIndex = 85;
            this.label2.Text = "Menü neve:";
            // 
            // textbox_mnev
            // 
            this.textbox_mnev.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textbox_mnev.Location = new System.Drawing.Point(487, 186);
            this.textbox_mnev.Name = "textbox_mnev";
            this.textbox_mnev.Size = new System.Drawing.Size(391, 29);
            this.textbox_mnev.TabIndex = 84;
            // 
            // listBox_menu
            // 
            this.listBox_menu.Dock = System.Windows.Forms.DockStyle.Left;
            this.listBox_menu.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.listBox_menu.FormattingEnabled = true;
            this.listBox_menu.ItemHeight = 20;
            this.listBox_menu.Location = new System.Drawing.Point(0, 0);
            this.listBox_menu.Name = "listBox_menu";
            this.listBox_menu.Size = new System.Drawing.Size(320, 538);
            this.listBox_menu.TabIndex = 82;
            this.listBox_menu.SelectedIndexChanged += new System.EventHandler(this.listBox_menu_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(397, 153);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 24);
            this.label1.TabIndex = 92;
            this.label1.Text = "Menü id:";
            // 
            // numericUpDown_mar
            // 
            this.numericUpDown_mar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.numericUpDown_mar.Location = new System.Drawing.Point(487, 221);
            this.numericUpDown_mar.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown_mar.Name = "numericUpDown_mar";
            this.numericUpDown_mar.Size = new System.Drawing.Size(215, 29);
            this.numericUpDown_mar.TabIndex = 93;
            // 
            // button_clean
            // 
            this.button_clean.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_clean.Location = new System.Drawing.Point(411, 295);
            this.button_clean.Name = "button_clean";
            this.button_clean.Size = new System.Drawing.Size(115, 40);
            this.button_clean.TabIndex = 94;
            this.button_clean.Text = "Clean";
            this.button_clean.UseVisualStyleBackColor = true;
            this.button_clean.Click += new System.EventHandler(this.button_clean_Click);
            // 
            // form_menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(911, 538);
            this.Controls.Add(this.button_clean);
            this.Controls.Add(this.numericUpDown_mar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.numericUpDown_mazon);
            this.Controls.Add(this.button_vevo_torles);
            this.Controls.Add(this.button_vevo_rogzites);
            this.Controls.Add(this.button_vevo_modosit);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textbox_mnev);
            this.Controls.Add(this.listBox_menu);
            this.Name = "form_menu";
            this.Text = "form_menu";
            this.Load += new System.EventHandler(this.form_menu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_mazon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_mar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.NumericUpDown numericUpDown_mazon;
        private System.Windows.Forms.Button button_vevo_torles;
        private System.Windows.Forms.Button button_vevo_rogzites;
        private System.Windows.Forms.Button button_vevo_modosit;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textbox_mnev;
        private System.Windows.Forms.ListBox listBox_menu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numericUpDown_mar;
        private System.Windows.Forms.Button button_clean;
    }
}