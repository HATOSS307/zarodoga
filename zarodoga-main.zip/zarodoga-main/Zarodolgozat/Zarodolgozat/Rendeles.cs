﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zarodolgozat
{
    internal class Rendeles
    {
        int razon;
        int vazon; 
        int fazon;
        DateTime idopont;

        public int Razon { get => razon; set => razon = value; }

        public int Vazon { get => vazon; set => vazon = value; }

        public int Fazon { get => fazon; set => fazon = value; }

        public DateTime Idopont { get => idopont; set => idopont = DateTime.Now; }


        public Rendeles(int razon, int vazon, int fazon, DateTime idopont)
        {
            Razon = razon;
            Vazon = vazon;
            Fazon = fazon;
            Idopont = idopont;

        }
    }
}
