﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zarodolgozat
{
    internal class Futar
    {
        int fazon;
        string fnev;
       

        public int Fazon { get => fazon; set => fazon = value; }
        public string Fnev { get => fnev; set => fnev = value; }
        

        public Futar(int fazon, string fnev)
        {
            Fazon = fazon;
            Fnev = fnev;

        }
    }
}
