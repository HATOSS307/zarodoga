﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Zarodolgozat
{
    public partial class form_login : Form
    {
        MySqlConnection connect = null;
        MySqlCommand cmd = null;
        public form_login()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder builder = new MySqlConnectionStringBuilder();
            builder.Server = "localhost";
            builder.UserID = "root";
            builder.Password = "";
            builder.Database = "zarodolgozat_hadhazi";
            connect = new MySqlConnection(builder.ConnectionString);
            try
            {               
                connect.Open();
                cmd = connect.CreateCommand();
            }
            catch (MySqlException ex)
            {
                
                MessageBox.Show(ex.Message + Environment.NewLine + "A program leált");
                Environment.Exit(0);
            }
            finally
            {
                connect.Close();
            }
        }

        private void button_bejelentkez_Click(object sender, EventArgs e)
        {
            try
            {
                connect.Open();
                string query = "SELECT * FROM users WHERE bejelentkezes_felhasz = @username and bejelentkezes_jelszo=@password";
                MySqlCommand cmd = new MySqlCommand(query, connect);
                cmd.Parameters.AddWithValue("@username", textBox1_felhasznalonev.Text);
                cmd.Parameters.AddWithValue("@password", textBox1_jelszo.Text);
                MySqlDataReader reader = cmd.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    Program.Form_Kezdolap.Show();
                    FormClosing -= form_login_FormClosing;
                    Program.Form_Login.Hide();
                }
                else
                {
                    MessageBox.Show("Hibás felhasználónév és vagy jelszó");
                }
            }
            catch (Exception )
            {           
                connect.Close();
                throw;
            }
            connect.Close();

        }

        private void button_clear_Click(object sender, EventArgs e)
        {
            textBox1_felhasznalonev.Text = "";
            textBox1_jelszo.Text = "";
        }

        private void form_login_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
