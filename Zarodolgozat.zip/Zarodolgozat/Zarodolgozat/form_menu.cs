﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zarodolgozat
{
    public partial class form_menu : Form
    {

        MySqlConnection connect = null;
        MySqlCommand cmd = null;
        public form_menu()
        {
            InitializeComponent();
        }

        private void form_menu_Load(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder builder = new MySqlConnectionStringBuilder();
            builder.Server = "localhost";
            builder.UserID = "root";
            builder.Password = "";
            builder.Database = "zarodolgozat_hadhazi";
            connect = new MySqlConnection(builder.ConnectionString);
            try
            {
                connect.Open();
                cmd = connect.CreateCommand();
            }
            catch (MySqlException ex)
            {

                MessageBox.Show(ex.Message + Environment.NewLine + "A program leált");
                Environment.Exit(0);
            }
            finally
            {
                connect.Close();
            }
            menu_list_update();

        }

        private void menu_list_update()
        {

            listBox_menu.Items.Clear();
            cmd.CommandText = "SELECT * FROM `menu`";
            connect.Open();
            using (MySqlDataReader dr = cmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    Menu uj = new Menu(dr.GetInt32("mazon"), dr.GetString("mnev"), dr.GetInt32("mar"));
                    listBox_menu.Items.Add(uj);
                }
            }
            connect.Close();
        }

        private void button_vevo_modosit_Click(object sender, EventArgs e)
        {
            if (listBox_menu.SelectedIndex < 0)
            {
                MessageBox.Show("Nincs kijelölve adat!");
                return;
            }
            Menu kivalasztott_adat = (Menu)listBox_menu.SelectedItem;
            cmd.CommandText = "UPDATE `menu` SET mnev = @mnev, mar = @mar   WHERE mazon = @mazon";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@mazon", numericUpDown_mazon.Value);
            cmd.Parameters.AddWithValue("@mnev", textbox_mnev.Text);
            cmd.Parameters.AddWithValue("@mar", numericUpDown_mar.Value);
            connect.Open();
            if (cmd.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Módosítás sikeres");
                connect.Close();
                textbox_mnev.Text = "";
                numericUpDown_mazon.Value = numericUpDown_mazon.Minimum;
                numericUpDown_mar.Value = numericUpDown_mar.Minimum;    
                menu_list_update();
            }
            else
            {
                MessageBox.Show("Az adatok Módosítása sikertelen!");

            }
            if (connect.State == ConnectionState.Open)
            {
                connect.Close();

            }
        }

        private void button_vevo_rogzites_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textbox_mnev.Text))
            {
                MessageBox.Show("Adja meg a nevet");
                textbox_mnev.Focus();
                return;
            }
            if (numericUpDown_mar.Value < 0)
            {
                MessageBox.Show("Érvénytelen ár!");
                numericUpDown_mar.Focus();
                return;
            }
            if (numericUpDown_mazon.Value < 0)
            {
                MessageBox.Show("Érvénytelen azonosító!");
                numericUpDown_mazon.Focus();
                return;
            }
            cmd.CommandText = "INSERT INTO `menu` (`mazon`, `mnev`, `mar`) VALUES (@mazon, @mnev, @mar);";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@mazon", numericUpDown_mazon.Value);
            cmd.Parameters.AddWithValue("@mnev", textbox_mnev.Text);
            cmd.Parameters.AddWithValue("@mar", numericUpDown_mar.Value);
            connect.Open();
            try
            {
                if (cmd.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Sikeres adat rögzítés");
                    textbox_mnev.Text = "";
                    numericUpDown_mazon.Value = numericUpDown_mazon.Minimum;
                    numericUpDown_mar.Value = numericUpDown_mar.Minimum;

                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);

            }
            connect.Close();
            menu_list_update();
        }

        private void button_vevo_torles_Click(object sender, EventArgs e)
        {
            if (listBox_menu.SelectedIndex < 0)
            {
                return;
            }
            cmd.CommandText = "DELETE FROM `menu` WHERE mazon = @mazon";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@mazon", numericUpDown_mar.Value);
            connect.Open();

            if (cmd.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("A törlés sikeres!");
                connect.Close();
                textbox_mnev.Text = "";
                numericUpDown_mar.Value = numericUpDown_mar.Minimum;
                numericUpDown_mazon.Value = numericUpDown_mazon.Minimum;
                menu_list_update();
            }
            else
            {
                MessageBox.Show("A törlés sikertelen!");
            }
            connect.Close();
        }

        private void listBox_menu_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox_menu.SelectedIndex < 0)
            {
                return;
            }
            Menu kivaasztott_adat = (Menu)listBox_menu.SelectedItem;
            textbox_mnev.Text = kivaasztott_adat.Mnev;
            numericUpDown_mazon.Value = Convert.ToDecimal(kivaasztott_adat.Mazon);
            numericUpDown_mar.Value = Convert.ToInt32(kivaasztott_adat.Mar);
        }

        private void button_clean_Click(object sender, EventArgs e)
        {
            textbox_mnev.Text = "";
            numericUpDown_mazon.Value = numericUpDown_mazon.Minimum;
            numericUpDown_mar.Value = numericUpDown_mar.Minimum;
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            Program.Form_Menu.Close();
        }
    }
}
