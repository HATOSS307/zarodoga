﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zarodolgozat
{
    internal static class Program
    {
        static public form_login Form_Login = null;
        static public form_kezdolap Form_Kezdolap= null;
        static public form_vevo Form_Vevo= null;
        static public form_futar Form_Futar = null;
        static public form_menu Form_Menu = null;
        static public form_rendeles Form_Rendeles = null;
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Form_Login = new form_login();
            Form_Kezdolap = new form_kezdolap();
            Form_Vevo = new form_vevo();
            Form_Futar = new form_futar();
            Form_Menu = new form_menu();
            Form_Rendeles = new form_rendeles();
            Form_Login.ShowDialog();
            Application.Run(Form_Kezdolap);
            Form_Kezdolap.Hide();
        }
    }
}
