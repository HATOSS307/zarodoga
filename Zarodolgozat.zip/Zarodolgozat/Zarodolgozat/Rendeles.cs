﻿using MySql.Data.Types;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zarodolgozat
{
    internal class Rendeles
    {
        
        DateTime idopont;
        string vevonev;
        string vevocim;
        string futarnev;
        int tetel_darab;
        string menunev;
        int menuar;

       

        public DateTime Idopont { get => idopont; set => idopont = value; }
        public string Vevonev { get => vevonev; set => vevonev = value; }
        public string Vevocim { get => vevocim; set => vevocim = value; }
        public string Futarnev { get => futarnev; set => futarnev = value; }
        public int Tetel_darab { get => tetel_darab; set => tetel_darab = value; }
        public string Menunev { get => menunev; set => menunev = value; }
        public int Menuar { get => menuar; set => menuar = value; }

         public Rendeles(DateTime idopont, string vevonev, string vevocim, string futarnev, int tetel_darab, string menunev, int menuar)
         {
                    Idopont = idopont;
                    Vevonev = vevonev;
                    Vevocim = vevocim;
                    Futarnev = futarnev;
                    Tetel_darab = tetel_darab;
                    Menunev = menunev;
                    Menuar = menuar;
         }
        public override string ToString()
        {
            return $"{vevonev}   {menuar}Ft";
        }
    }
}
