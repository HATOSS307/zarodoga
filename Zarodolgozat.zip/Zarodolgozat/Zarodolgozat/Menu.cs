﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zarodolgozat
{
    internal class Menu
    {
        int mazon;
        string mnev;
        int mar;

        public int Mazon { get => mazon; set => mazon = value; }
        public string Mnev { get => mnev; set => mnev = value; }

        public int Mar { get => mar; set => mar = value; }


        public Menu(int mazon, string mnev, int mar)
        {
            Mazon  = mazon;
            Mnev = mnev;
            Mar = mar;

        }
        public override string ToString()
        {
            return mnev;
        }
    }
}
