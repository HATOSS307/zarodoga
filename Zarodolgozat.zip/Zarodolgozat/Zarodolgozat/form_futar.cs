﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Zarodolgozat
{
    public partial class form_futar : Form
    {
        MySqlConnection connect = null;
        MySqlCommand cmd = null;
        public form_futar()
        {
            InitializeComponent();
        }

        private void form_futar_Load(object sender, EventArgs e)
        {
            MySqlConnectionStringBuilder builder = new MySqlConnectionStringBuilder();
            builder.Server = "localhost";
            builder.UserID = "root";
            builder.Password = "";
            builder.Database = "zarodolgozat_hadhazi";
            connect = new MySqlConnection(builder.ConnectionString);
            try
            {
                connect.Open();
                cmd = connect.CreateCommand();
            }
            catch (MySqlException ex)
            {

                MessageBox.Show(ex.Message + Environment.NewLine + "A program leált");
                Environment.Exit(0);
            }
            finally
            {
                connect.Close();
            }
            futar_list_update();
        }

        private void futar_list_update()
        {

            listBox_futar.Items.Clear();
            cmd.CommandText = "SELECT * FROM `futar`";
            connect.Open();
            using (MySqlDataReader dr = cmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    Futar uj = new Futar(dr.GetInt32("fazon"), dr.GetString("fnev"));
                    listBox_futar.Items.Add(uj);
                }
            }
            connect.Close();
        }

        private void button_vevo_modosit_Click(object sender, EventArgs e)
        {
            if (listBox_futar.SelectedIndex < 0)
            {
                MessageBox.Show("Nincs kijelölve adat!");
                return;
            }
            Futar kivalasztott_adat = (Futar)listBox_futar.SelectedItem;
            cmd.CommandText = "UPDATE `futar` SET fnev = @fnev WHERE fazon = @fazon";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@fazon", numericUpDown_fazon.Value);
            cmd.Parameters.AddWithValue("@fnev", textbox_fnev.Text);
            connect.Open();
            if (cmd.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Módosítás sikeres");
                connect.Close();
                textbox_fnev.Text = "";
                numericUpDown_fazon.Value = numericUpDown_fazon.Minimum;
                futar_list_update();
            }
            else
            {
                MessageBox.Show("Az adatok Módosítása sikertelen!");

            }
            if (connect.State == ConnectionState.Open)
            {
                connect.Close();

            }
        }

        private void button_vevo_rogzites_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(textbox_fnev.Text))
            {
                MessageBox.Show("Adja meg a nevet");
                textbox_fnev.Focus();
                return;
            }
            if (numericUpDown_fazon.Value < 0)
            {
                MessageBox.Show("Érvénytelen egységár!");
                numericUpDown_fazon.Focus();
                return;
            }
            cmd.CommandText = "INSERT INTO `futar` (`fazon`, `fnev`) VALUES (@fazon, @fnev);";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@fazon", numericUpDown_fazon.Value);
            cmd.Parameters.AddWithValue("@fnev", textbox_fnev.Text );
            connect.Open();
            try
            {
                if (cmd.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Sikeres adat rögzítés");
                    textbox_fnev.Text = "";
                    numericUpDown_fazon.Value = numericUpDown_fazon.Minimum;

                }
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);

            }
            connect.Close();
            futar_list_update();

        }

        private void button_vevo_torles_Click(object sender, EventArgs e)
        {
            if (listBox_futar.SelectedIndex < 0)
            {
                return;
            }
            cmd.CommandText = "DELETE FROM `futar` WHERE fazon = @fazon";
            cmd.Parameters.Clear();
            cmd.Parameters.AddWithValue("@fazon", numericUpDown_fazon.Value);
            connect.Open();

            if (cmd.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("A törlés sikeres!");
                connect.Close();
                textbox_fnev.Text = "";
                numericUpDown_fazon.Value = numericUpDown_fazon.Minimum;
                futar_list_update();
            }
            else
            {
                MessageBox.Show("A törlés sikertelen!");
            }
            connect.Close();
        }

        private void listBox_futar_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox_futar.SelectedIndex < 0)
            {
                return;
            }
            Futar kivaasztott_adat = (Futar)listBox_futar.SelectedItem;
            textbox_fnev.Text = kivaasztott_adat.Fnev;
            numericUpDown_fazon.Value = Convert.ToDecimal(kivaasztott_adat.Fazon);
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            Program.Form_Futar.Close();
        }

        private void button_clean_Click(object sender, EventArgs e)
        {
            textbox_fnev.Text = "";
            numericUpDown_fazon.Value = numericUpDown_fazon.Minimum;
        }
    }
}
