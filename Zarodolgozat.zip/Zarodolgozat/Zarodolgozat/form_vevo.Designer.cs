﻿namespace Zarodolgozat
{
    partial class form_vevo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox_vevo = new System.Windows.Forms.ListBox();
            this.textBox_vcim = new System.Windows.Forms.TextBox();
            this.textbox_vnev = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button_vevo_modosit = new System.Windows.Forms.Button();
            this.button_vevo_rogzites = new System.Windows.Forms.Button();
            this.button_vevo_torles = new System.Windows.Forms.Button();
            this.numericUpDown_vazon = new System.Windows.Forms.NumericUpDown();
            this.button_exit = new System.Windows.Forms.Button();
            this.button_clean = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_vazon)).BeginInit();
            this.SuspendLayout();
            // 
            // listBox_vevo
            // 
            this.listBox_vevo.Dock = System.Windows.Forms.DockStyle.Left;
            this.listBox_vevo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.listBox_vevo.FormattingEnabled = true;
            this.listBox_vevo.ItemHeight = 20;
            this.listBox_vevo.Location = new System.Drawing.Point(0, 0);
            this.listBox_vevo.Name = "listBox_vevo";
            this.listBox_vevo.Size = new System.Drawing.Size(239, 538);
            this.listBox_vevo.TabIndex = 0;
            this.listBox_vevo.SelectedIndexChanged += new System.EventHandler(this.listBox_vevo_SelectedIndexChanged);
            // 
            // textBox_vcim
            // 
            this.textBox_vcim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox_vcim.Location = new System.Drawing.Point(513, 271);
            this.textBox_vcim.Name = "textBox_vcim";
            this.textBox_vcim.Size = new System.Drawing.Size(221, 26);
            this.textBox_vcim.TabIndex = 2;
            // 
            // textbox_vnev
            // 
            this.textbox_vnev.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textbox_vnev.Location = new System.Drawing.Point(513, 204);
            this.textbox_vnev.Name = "textbox_vnev";
            this.textbox_vnev.Size = new System.Drawing.Size(221, 26);
            this.textbox_vnev.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(442, 148);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 20);
            this.label1.TabIndex = 4;
            this.label1.Text = "Vevő id:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(420, 204);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Vevő neve:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(422, 277);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 20);
            this.label3.TabIndex = 6;
            this.label3.Text = "Vevő címe:";
            // 
            // button_vevo_modosit
            // 
            this.button_vevo_modosit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_vevo_modosit.Location = new System.Drawing.Point(525, 337);
            this.button_vevo_modosit.Name = "button_vevo_modosit";
            this.button_vevo_modosit.Size = new System.Drawing.Size(111, 40);
            this.button_vevo_modosit.TabIndex = 7;
            this.button_vevo_modosit.Text = "Módosít";
            this.button_vevo_modosit.UseVisualStyleBackColor = true;
            this.button_vevo_modosit.Click += new System.EventHandler(this.button_vevo_modosit_Click);
            // 
            // button_vevo_rogzites
            // 
            this.button_vevo_rogzites.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_vevo_rogzites.Location = new System.Drawing.Point(642, 337);
            this.button_vevo_rogzites.Name = "button_vevo_rogzites";
            this.button_vevo_rogzites.Size = new System.Drawing.Size(121, 41);
            this.button_vevo_rogzites.TabIndex = 8;
            this.button_vevo_rogzites.Text = "Rögzítés";
            this.button_vevo_rogzites.UseVisualStyleBackColor = true;
            this.button_vevo_rogzites.Click += new System.EventHandler(this.button_vevo_rogzites_Click);
            // 
            // button_vevo_torles
            // 
            this.button_vevo_torles.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_vevo_torles.Location = new System.Drawing.Point(756, 420);
            this.button_vevo_torles.Name = "button_vevo_torles";
            this.button_vevo_torles.Size = new System.Drawing.Size(143, 50);
            this.button_vevo_torles.TabIndex = 9;
            this.button_vevo_torles.Text = "Végleges Törlés";
            this.button_vevo_torles.UseVisualStyleBackColor = true;
            this.button_vevo_torles.Click += new System.EventHandler(this.button_vevo_torles_Click);
            // 
            // numericUpDown_vazon
            // 
            this.numericUpDown_vazon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.numericUpDown_vazon.Location = new System.Drawing.Point(513, 148);
            this.numericUpDown_vazon.Name = "numericUpDown_vazon";
            this.numericUpDown_vazon.Size = new System.Drawing.Size(99, 26);
            this.numericUpDown_vazon.TabIndex = 10;
            // 
            // button_exit
            // 
            this.button_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_exit.ForeColor = System.Drawing.Color.Black;
            this.button_exit.Location = new System.Drawing.Point(756, 476);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(143, 50);
            this.button_exit.TabIndex = 81;
            this.button_exit.Text = "Vissza";
            this.button_exit.UseVisualStyleBackColor = true;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // button_clean
            // 
            this.button_clean.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_clean.Location = new System.Drawing.Point(409, 337);
            this.button_clean.Name = "button_clean";
            this.button_clean.Size = new System.Drawing.Size(110, 40);
            this.button_clean.TabIndex = 95;
            this.button_clean.Text = "Clean";
            this.button_clean.UseVisualStyleBackColor = true;
            this.button_clean.Click += new System.EventHandler(this.button_clean_Click);
            // 
            // form_vevo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gainsboro;
            this.ClientSize = new System.Drawing.Size(911, 538);
            this.Controls.Add(this.button_clean);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.numericUpDown_vazon);
            this.Controls.Add(this.button_vevo_torles);
            this.Controls.Add(this.button_vevo_rogzites);
            this.Controls.Add(this.button_vevo_modosit);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textbox_vnev);
            this.Controls.Add(this.textBox_vcim);
            this.Controls.Add(this.listBox_vevo);
            this.Name = "form_vevo";
            this.Text = "Form_vevo";
            this.Load += new System.EventHandler(this.Form_vevo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_vazon)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox_vevo;
        private System.Windows.Forms.TextBox textBox_vcim;
        private System.Windows.Forms.TextBox textbox_vnev;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button_vevo_modosit;
        private System.Windows.Forms.Button button_vevo_rogzites;
        private System.Windows.Forms.Button button_vevo_torles;
        private System.Windows.Forms.NumericUpDown numericUpDown_vazon;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.Button button_clean;
    }
}